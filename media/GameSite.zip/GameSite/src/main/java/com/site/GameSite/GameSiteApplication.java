package com.site.GameSite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameSiteApplication.class, args);
	}

}
